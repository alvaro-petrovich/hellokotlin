package mx.edu.ittehuacan.hellokotlin.kotlin.model

interface IPlayer {

  fun play()

  fun injured(): Boolean

}