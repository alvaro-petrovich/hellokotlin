package mx.edu.ittehuacan.hellokotlin.kotlin.model

data class Animal(
  val name: String,
  val type: String,
  val hasTail: Boolean
) {
}