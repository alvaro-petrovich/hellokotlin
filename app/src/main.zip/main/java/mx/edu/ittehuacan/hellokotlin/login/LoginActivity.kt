package mx.edu.ittehuacan.hellokotlin.login

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import mx.edu.ittehuacan.hellokotlin.R

class LoginActivity : AppCompatActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_login)
  }
}