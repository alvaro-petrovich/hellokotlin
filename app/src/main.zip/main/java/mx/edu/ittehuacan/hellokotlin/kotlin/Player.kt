package mx.edu.ittehuacan.hellokotlin.kotlin

data class Player( var name: String, var age: Int ) {}